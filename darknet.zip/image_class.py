# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 18:06:35 2019

@author: moon
"""

from matplotlib import pyplot as plt

import numpy as np
import os
import tensorflow as tf
import sys

from nets import inception
from preprocessing import inception_preprocessing

checkpoints_dir = '/home/moon/tmp/train_inception_resnet_last3/all'

slim = tf.contrib.slim

image_size = inception.inception_resnet_v2.default_image_size    



        
with tf.Graph().as_default():
    image_files = os.listdir("/home/moon/git/darknet/results")
    for file in image_files:
        os.remove("/home/moon/git/darknet/results/" + '/' + file)
        print('remove complete')
        
    os.system("./darknet detect cfg/yolov3.cfg yolov3.weights data/dog7.jpeg -out result")

    user_images = [] # 복수의 원본 이미지
    user_processed_images = [] # 복수의 전처리된 이미지

    image_files = os.listdir("/home/moon/git/darknet/results") # 분류하고 싶은 이미지가 저장된 폴더

    if not bool(image_files):
        print('dog is not here')    
        sys.exit(1)

    for i in image_files:
        image_input = tf.read_file("/home/moon/git/darknet/results/" +'/'+ i)
        image = tf.image.decode_jpeg(image_input, channels=3)
        user_images.append(image)
        processed_image = inception_preprocessing.preprocess_image(image, image_size, image_size, is_training=False)
        user_processed_images.append(processed_image)
        
    processed_images  = tf.expand_dims(processed_image, 0)
    
    with slim.arg_scope(inception.inception_resnet_v2_arg_scope()):
        logits, _ = inception.inception_resnet_v2(user_processed_images, num_classes=4, is_training=False)
    probabilities = tf.nn.softmax(logits)

    init_fn = slim.assign_from_checkpoint_fn(
        os.path.join(checkpoints_dir, 'model.ckpt-25000'),
        slim.get_model_variables('InceptionResnetV2'))

    with tf.Session() as sess:
        init_fn(sess)
        np_images, probabilities = sess.run([user_images, probabilities])
    
    names = os.listdir("/home/moon/tmp/dog/dog_photos")
    

    for files in range(len(image_files)):
        probabilitie = probabilities[files, 0:]
        sorted_inds = [i[0] for i in sorted(enumerate(-probabilitie), key=lambda x:x[1])]


        print(files)
        for p in range(2):
            index = sorted_inds[p]
            print('Probability %0.2f%% => [%s]' % (probabilitie[index], names[index]))
