# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 07:38:41 2019

@author: moon
"""

from matplotlib import pyplot as plt

import sys
import numpy as np
import os
import string
import tensorflow as tf

from nets import inception
from preprocessing import inception_preprocessing

checkpoints_dir = '/home/moon/tmp/train_inception_resnet_logs2/all'
slim = tf.contrib.slim

image_size = inception.inception_resnet_v2.default_image_size

with tf.Graph().as_default():
    image_input = tf.read_file(sys.argv[1])
    image = tf.image.decode_jpeg(image_input, channels=3)
    processed_image = inception_preprocessing.preprocess_image(image,
                                                               image_size,
                                                               image_size,
                                                               is_training=False)
    processed_images = tf.expand_dims(processed_image, 0)
    
    with slim.arg_scope(inception.inception_resnet_v2_arg_scope()):
        logits, _ = inception.inception_resnet_v2(processed_images, num_classes=2, is_training=False)
    probabilities = tf.nn.softmax(logits)
    
    init_fn = slim.assign_from_checkpoint_fn(
        os.path.join(checkpoints_dir, 'model.ckpt-10000'),
        slim.get_model_variables('InceptionResnetV2'))
        
    with tf.Session() as sess:
        init_fn(sess)
        np_image, probabilities = sess.run([image, probabilities])
        probabilities = probabilities[0, 0:]
        sorted_inds = [i[0] for i in sorted(enumerate(-probabilities), key=lambda x:x[1])]
        
   # plt.figure()
   # plt.imshow(np_image.astype(np.uint8))
   # plt.axis('off')
   # plt.show()
    
    names = os.listdir("/home/moon/tmp/dogs/dogs_photos")
    for i in range(2):
        index = sorted_inds[i]
        print('Probability %0.2f%% => [%s]' % (probabilities[index], names[index]))
    