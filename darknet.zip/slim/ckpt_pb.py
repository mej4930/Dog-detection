# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 03:36:17 2019

@author: moon
"""

import tensorflow as tf
from tensorflow.contrib import slim

from nets import inception
from tensorflow.python.framework.graph_util import convert_variables_to_constants
from tensorflow.python.tools.optimize_for_inference_lib import optimize_for_inference
from preprocessing import inception_preprocessing

checkpoints_dir = '/home/moon/tmp/train_inception_resnet_v1_logs'
OUTPUT_PB_FILENAME = 'minimal_graph.proto'
NUM_CLASSES = 2

image_size = inception.inception_v1.default_image_size

with tf.Graph().as_default():
    input_image_t = tf.placeholder(tf.string, name='input_image')
    image = tf.image.decode_jpeg(input_image_t, channels=3)
    
    processed_image = inception_preprocessing.preprocess_for_eval(image,
                                                                  image_size,
                                                                  image_size, central_fraction=None)
                                                                  
    processed_images = tf.expand_dims(processed_image, 0)
    
    with slim.arg_scope(inception.inception_v1_arg_scope()):
        logits, _=inception.inception_v1(processed_images,
                                         num_classes=NUM_CLASSES,
                                         is_training=False)
                                         
    probabilities = tf.nn.softmax(logits)
    
    model_path = tf.train.latest_checkpoint(checkpoints_dir)
    
    init_fn = slim.assign_from_checkpoint_fn(
        model_path,
        slim.get_model_variables())
    
    with tf.Session() as sess:
        init_fn(sess)
        
    constant_graph = convert_variables_to_constants(sess, sess.graph_def, ["input_image", "DecodeJpeg", "InceptionV1/Logits/Predictions/Softmax"])
        
    optimized_constant_graph = optimize_for_inference(constant_graph, ["input_image"],
                                                      ["InceptionV1/Logits/Predictions/Softmax"], tf.string.as_datatype_enum)
                                                      
    tf.train.write_graph(optimized_constant_graph, '.', OUTPUT_PB_FILENAME, as_text=False)